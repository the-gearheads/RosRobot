// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__SRV__TRIGGER_HPP_
#define EXAMPLE_INTERFACES__SRV__TRIGGER_HPP_

#include "example_interfaces/srv/detail/trigger__struct.hpp"
#include "example_interfaces/srv/detail/trigger__builder.hpp"
#include "example_interfaces/srv/detail/trigger__traits.hpp"

#endif  // EXAMPLE_INTERFACES__SRV__TRIGGER_HPP_
