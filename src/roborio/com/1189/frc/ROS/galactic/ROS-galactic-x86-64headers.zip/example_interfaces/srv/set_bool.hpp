// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__SRV__SET_BOOL_HPP_
#define EXAMPLE_INTERFACES__SRV__SET_BOOL_HPP_

#include "example_interfaces/srv/detail/set_bool__struct.hpp"
#include "example_interfaces/srv/detail/set_bool__builder.hpp"
#include "example_interfaces/srv/detail/set_bool__traits.hpp"

#endif  // EXAMPLE_INTERFACES__SRV__SET_BOOL_HPP_
