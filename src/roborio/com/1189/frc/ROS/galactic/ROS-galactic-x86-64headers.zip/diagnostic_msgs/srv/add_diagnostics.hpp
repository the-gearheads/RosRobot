// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_HPP_
#define DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_HPP_

#include "diagnostic_msgs/srv/detail/add_diagnostics__struct.hpp"
#include "diagnostic_msgs/srv/detail/add_diagnostics__builder.hpp"
#include "diagnostic_msgs/srv/detail/add_diagnostics__traits.hpp"

#endif  // DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_HPP_
