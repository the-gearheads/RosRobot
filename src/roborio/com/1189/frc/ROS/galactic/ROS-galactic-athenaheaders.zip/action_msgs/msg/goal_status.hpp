// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTION_MSGS__MSG__GOAL_STATUS_HPP_
#define ACTION_MSGS__MSG__GOAL_STATUS_HPP_

#include "action_msgs/msg/detail/goal_status__struct.hpp"
#include "action_msgs/msg/detail/goal_status__builder.hpp"
#include "action_msgs/msg/detail/goal_status__traits.hpp"

#endif  // ACTION_MSGS__MSG__GOAL_STATUS_HPP_
