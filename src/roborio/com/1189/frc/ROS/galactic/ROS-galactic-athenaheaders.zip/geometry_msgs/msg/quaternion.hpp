// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__QUATERNION_HPP_
#define GEOMETRY_MSGS__MSG__QUATERNION_HPP_

#include "geometry_msgs/msg/detail/quaternion__struct.hpp"
#include "geometry_msgs/msg/detail/quaternion__builder.hpp"
#include "geometry_msgs/msg/detail/quaternion__traits.hpp"

#endif  // GEOMETRY_MSGS__MSG__QUATERNION_HPP_
