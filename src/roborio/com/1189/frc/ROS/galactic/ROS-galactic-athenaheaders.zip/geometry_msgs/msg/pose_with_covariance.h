// generated from rosidl_generator_c/resource/idl.h.em
// with input from geometry_msgs:msg/PoseWithCovariance.idl
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__POSE_WITH_COVARIANCE_H_
#define GEOMETRY_MSGS__MSG__POSE_WITH_COVARIANCE_H_

#include "geometry_msgs/msg/detail/pose_with_covariance__struct.h"
#include "geometry_msgs/msg/detail/pose_with_covariance__functions.h"
#include "geometry_msgs/msg/detail/pose_with_covariance__type_support.h"

#endif  // GEOMETRY_MSGS__MSG__POSE_WITH_COVARIANCE_H_
